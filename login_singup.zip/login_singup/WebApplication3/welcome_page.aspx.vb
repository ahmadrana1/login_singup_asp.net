﻿Public Class frmwelcome
    Inherits System.Web.UI.Page
    Dim conn As New SqlClient.SqlConnection("Data Source=HOME-FAN-04;Initial Catalog=singup_page;User ID=sa;Password=kelplantmp2")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub

End Class