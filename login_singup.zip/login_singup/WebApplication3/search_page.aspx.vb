﻿Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Public Class WebForm1
    Inherits System.Web.UI.Page
    Dim conn As New SqlClient.SqlConnection("Data Source=HOME-FAN-04;Initial Catalog=singup_page;User ID=sa;Password=kelplantmp2")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim a As String = "select Uemail from user_info"
            Dim b As New SqlClient.SqlCommand(a, conn)
            Dim c As New SqlDataAdapter(b)
            Dim d As New DataTable
            c.Fill(d)
            ddlist1.DataSource = d
            ddlist1.DataTextField = "Uemail"
            ddlist1.DataBind()
            ddlist1.Items.Insert(0, New ListItem(""))
        End If

        Dim cmd As New SqlDataAdapter
        Dim ds As New DataSet
        Try
            conn.Open()
            cmd = New SqlDataAdapter("select username, password, contact from user_info where Uemail = '" & ddlist1.Text & "'", conn)
            cmd.Fill(ds)
            conn.Close()

            If ds.Tables(0).Rows.Count > 0 Then
                txt1.Text = ds.Tables(0).Rows(0)("username").ToString
                Txt2.Text = ds.Tables(0).Rows(0)("password").ToString
                Txt3.Text = ds.Tables(0).Rows(0)("contact").ToString
            End If
        Catch ex As Exception
            conn.Close()
        End Try

    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Dim cmd As New SqlClient.SqlCommand

        If txtsearch.Text = "" Then
            Response.Write("<script>alert('Please provide Email to find data in Databases!')</script>")
        End If
        'Try
        '    conn.Open()
        '    cmd.Connection = conn
        '    cmd.CommandText = ("select username, password, contact from user_info where Uemail = '" & txtsearch.Text & "'")
        '    cmd.ExecuteScalar()
        '    txt1.Text = cmd.ExecuteScalar()
        '    conn.Close()
        'Catch ex As Exception
        '    conn.Close()
        'End Try

        Dim a As TextBox = New TextBox
        Dim adapter As SqlDataAdapter
        Dim ds As New DataSet
        Try
            conn.Open()
            adapter = New SqlDataAdapter("select username, password, contact from user_info where Uemail = '" & txtsearch.Text & "'", conn)
            adapter.Fill(ds)
            conn.Close()

            If ds.Tables(0).Rows.Count > 0 Then
                txt1.Text = ds.Tables(0).Rows(0)("username").ToString
                Txt2.Text = ds.Tables(0).Rows(0)("password").ToString
                Txt3.Text = ds.Tables(0).Rows(0)("contact").ToString
                a.Text = ds.Tables(0).Rows(0)("Uemail").ToString
            End If

            If txtsearch.Text <> a.Text Then
                Response.Write("<script>alert('No record found in Database!')</script>")
            End If

            conn.Close()
        Catch ex As Exception
            conn.Close()

        End Try
    End Sub

    Protected Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        Response.Redirect(Request.Url.AbsoluteUri,False)
    End Sub

    Protected Sub Backlogin_Click(sender As Object, e As EventArgs) Handles Backlogin.Click
        Server.Transfer("Login_page.aspx")
    End Sub
End Class