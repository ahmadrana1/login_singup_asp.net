﻿Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException

Public Class WebForm3
    Inherits System.Web.UI.Page
    Dim conn As New SqlClient.SqlConnection("Data Source=HOME-FAN-04;Initial Catalog=singup_page;User ID=sa;Password=kelplantmp2")


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click

        If txtemail.Text = "" Or txtusername.Text = "" Or txtpass.Text = "" Then

            Response.Write("<script>alert('Please fill all the required fields!')</script>")

        Else

            Dim a As TextBox = New TextBox
            Dim b As TextBox = New TextBox

            Dim cmd As New SqlClient.SqlCommand
            Dim adapter As SqlDataAdapter
            Dim ds As New DataSet
            Try
                conn.Open()
                adapter = New SqlDataAdapter("select Uemail from user_info where Uemail='" & txtemail.Text & "' ", conn)
                adapter.Fill(ds)
                conn.Close()
                If ds.Tables(0).Rows.Count > 0 Then
                    a.Text = ds.Tables(0).Rows(0)("Uemail").ToString
                End If
                conn.Close()
            Catch ex As Exception
                conn.Close()
            End Try

            If txtemail.Text = a.Text Then
                Response.Write("<script>alert('Email Already exists')</script>")
            Else

                If txtpass.Text <> txtrepas.Text Then

                    Response.Write("<script>alert('Passwords Mis-Matched')</script>")

                Else

                    Try
                        conn.Open()
                        cmd.Connection = conn
                        cmd.CommandText = "insert into user_info values ('" & txtemail.Text & "', '" & txtusername.Text & "', '" & txtpass.Text & "', '" & Txtphone.Text & "')"
                        cmd.ExecuteReader()
                        Response.Write("<script>alert('User successfully saved')</script>")
                        conn.Close()
                    Catch ex As Exception
                        conn.Close()
                    End Try
                End If
            End If
        End If

    End Sub

    Protected Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        Response.Redirect(Request.Url.AbsoluteUri)
    End Sub
End Class