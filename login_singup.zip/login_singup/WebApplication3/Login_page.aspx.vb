﻿Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Public Class WebForm2
    Inherits System.Web.UI.Page
    Dim conn As New SqlClient.SqlConnection("Data Source=HOME-FAN-04;Initial Catalog=singup_page;User ID=sa;Password=kelplantmp2")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub button1_Click(sender As Object, e As EventArgs) Handles btnsub.Click
        If txtlogin.Text = "" And txtpass.Text = "" Then

            Response.Write("<script>alert('Please provide all fields!')</script>")

        Else
            Dim a As TextBox = New TextBox
            Dim b As TextBox = New TextBox


            Dim cmd As New SqlClient.SqlCommand
            Dim adapter As SqlDataAdapter
            Dim ds As New DataSet
            Try
                conn.Open()
                adapter = New SqlDataAdapter("select Uemail, password from user_info where Uemail='" & txtlogin.Text & "' and password='" & txtpass.Text & "'", conn)
                adapter.Fill(ds)
                conn.Close()
                If ds.Tables(0).Rows.Count > 0 Then
                    a.Text = ds.Tables(0).Rows(0)("Uemail").ToString
                    b.Text = ds.Tables(0).Rows(0)("password").ToString
                End If
                conn.Close()

                'Response.Write("<script>alert('Username = " & a.Text & "\n""  Password =  " & b.Text & "')</script>")

            Catch ex As Exception
                conn.Close()
            End Try
            If txtlogin.Text <> a.Text Or txtpass.Text <> b.Text Then
                Response.Write("<script>alert('INVALID Email/Password')</script>")

            ElseIf txtlogin.Text <> a.Text And txtpass.Text <> b.Text Then

                Response.Write("<script>alert('Account not Found')</script>")
            ElseIf txtlogin.Text = a.Text Or txtpass.Text = b.Text Then
                'Response.Write("<script>alert('Welcome')</script>")

                'Response.Redirect("frmwelcome.aspx")

                Server.Transfer("welcome_page.aspx")
            End If
            End If

    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Server.Transfer("search_page.aspx")
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Server.Transfer("singup_page.aspx")
    End Sub

End Class